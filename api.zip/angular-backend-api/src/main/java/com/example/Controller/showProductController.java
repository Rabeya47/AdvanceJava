/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.Controller;

import com.example.DatabaseConnector;
import com.example.model.Product;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author PC MELA
 */
public class showProductController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            List<Product> plist = getProducts();
            String strplist = gson.toJson(plist);
            PrintWriter out = resp.getWriter();
            out.write(strplist);
            out.flush();
            out.close();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(showProductController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(showProductController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public List<Product> getProducts() throws ClassNotFoundException, SQLException {

        List<Product> plist = new ArrayList<>();
        Connection conn = DatabaseConnector.connector();
        String sql = "select * from products";

        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            
             plist.add(new Product(rs.getInt("id"), rs.getString("name"), rs.getInt("quantity"), rs.getDouble("price"), rs.getString("remarks")));

          
        }

          return plist;

    }

}
