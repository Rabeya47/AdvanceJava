/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

import com.example.model.APIResponse;
import com.example.model.Product;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.StyleConstants;

/**
 *
 * @author Instructor
 */
@WebServlet(name = "ProductRestApiController", urlPatterns = {"/add_product"})
public class ProductRestApiController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //-------start:--get request json data to java object
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        StringBuffer jb = Utility.requestBodyToStr(request);
        Product product = gson.fromJson(jb.toString(), Product.class);
        System.out.println("Product: " + gson.toJson(product));
        //--------end:-get request json data to java object

        //Api response 
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("product", product);
        APIResponse res = new APIResponse();

        // code here to send database=========================
        try {

            Product pro = saveProduct(product);
            if (pro != null) {

                res.setMessage("Successfull");
                res.setData(data);
                res.setStatusCode(200);

//res.getMessage("insert Successfully");
            } else {
                res.setMessage("failed");
                res.setData(data);
                res.setStatusCode(500);

            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProductRestApiController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ProductRestApiController.class.getName()).log(Level.SEVERE, null, ex);
        }

        //===========response======================
        response.setContentType("application/json");

        PrintWriter out = response.getWriter();

        out.write(gson.toJson(res));
        out.flush();
        out.close();

    }

    public static Product saveProduct(Product product) throws ClassNotFoundException, SQLException {

        Connection conn = DatabaseConnector.connector();
        String sql = "insert into products (name,quantity,price,remarks) values (?,?,?,?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, product.getName());
        pst.setInt(2, product.getQuantity());
        pst.setDouble(3, product.getPrice());
        pst.setString(4, product.getRemarks());
        int rs = pst.executeUpdate();
        if (rs > 0) {

            return product;

        }

        return null;

    }

}
