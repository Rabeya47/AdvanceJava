package com.example.util;

public class ValidateConstant {
   public enum Field {
        EMAIL,
        MOBILE,
        EMPTY
    }
    
}
