/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.jee47.Service;

import com.jee47.Model.Product;
import java.util.List;

/**
 *
 * @author Adon
 */
public interface InterProductService {

    public Product save(Product product);

    public List<Product> getAll();

    public boolean delete(long id);

    public Product getProductById(long id);

    public Product update(Product product);
}
