/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jee47.Service;

import com.jee47.Dao.InterProductDao;
import com.jee47.Dao.ProductDao;
import com.jee47.Model.Product;
import java.util.List;

/**
 *
 * @author Adon
 */
public class ProductService implements InterProductService{
    private InterProductDao productDao = null;

    public ProductService() {
        productDao = new ProductDao();
        
    }
    
    
    
    
        
    @Override
    public Product save(Product product) {
      return  productDao.save(product);
    }

    @Override
    public List<Product> getAll() {
       return  productDao.getAll();
    }

    @Override
    public boolean delete(long id) {
      return productDao.delete(id);
    }

    @Override
    public Product getProductById(long id) {
        return productDao.getProductById(id);
    }

    @Override
    public Product update(Product product) {
      return  productDao.save(product);  
    }
    
}
