/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jee47.Service;

import com.jee47.Dao.InterUserDao;
import com.jee47.Dao.UserDao;
import com.jee47.Model.UserModel;

/**
 *
 * @author Adon
 */
public class UserService implements InterUserService{
    private InterUserDao userDao;

    public UserService() {
        userDao =  new UserDao();
        
    }
    
    
    
    @Override
    public UserModel login(String username) {
        
       return userDao.login(username);
        
    }
   
}
