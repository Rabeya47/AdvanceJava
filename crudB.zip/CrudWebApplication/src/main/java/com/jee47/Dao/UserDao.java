/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jee47.Dao;

import com.jee47.Model.UserModel;
import com.jee47.Util.DatabaseConnector;
import com.mysql.cj.protocol.Resultset;
import com.sun.prism.Texture;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Adon
 */
public class UserDao implements InterUserDao{
    private Connection connect;
    
    
    public UserDao() {
        connect= DatabaseConnector.connect();
    }

    
    
    
    @Override
    public UserModel login(String username) {
        try {
            String sql = "Select * From crudtable where username=?";
            PreparedStatement pst = connect.prepareStatement(sql);
            System.out.println("Connection Success");
            
            pst.setString(1, username);
            ResultSet rs =  pst.executeQuery();
            while(rs.next()){
             String uname =   rs.getString("username");
             String pwd =   rs.getString("password");
             UserModel user = new UserModel();
             user.setUsername(uname);
             user.setPassword(pwd);
             
             return user;
            }
                    
            
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
}
