/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jee47.Dao;

import com.jee47.Model.Product;

import com.jee47.Util.DatabaseConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Adon
 */
public class ProductDao implements InterProductDao {

    private Connection conn;

    public ProductDao() {
        conn = DatabaseConnector.connect();
    }

    @Override
    public Product save(Product product) {

        try {
            String sql = "insert into products (name, price, quantity, remarks)" + "values(?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, product.getName());
            pst.setDouble(2, product.getPrice());
            pst.setInt(3, product.getQuantity());
            pst.setString(4, product.getRemarks());
            int rs = pst.executeUpdate();
            if (rs > 0) {

                return product;

            } else {
                return null;
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProductDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public List<Product> getAll() {
        List<Product> products = new ArrayList<>();
        try {

            String sql = "select * from products order by id desc";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Product product = new Product(rs.getLong("id"), rs.getString("name"), rs.getDouble("price"), rs.getInt("quantity"), rs.getString("remarks"));
                products.add(product);
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProductDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return products;
    }

    @Override
    public boolean delete(long id) {
        try {
            String sql = "delete from products where id  = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setLong(1, id);
            int rs = pst.executeUpdate();
            return (rs > 0) ? true : false;
     
        } catch (SQLException ex) {
            Logger.getLogger(ProductDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public Product getProductById(long id) {
     
        try {
            String sql = "Select * from products where id = ? ";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setLong(1, id);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
             Product product = new Product(rs.getLong("id"), rs.getString("name"), rs.getDouble("price"), rs.getInt("quantity"), rs.getString("remarks"));
            return product;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
       
    }

    @Override
    public Product update(Product product) {
        try {
            String sql = "update products set name = ?,   price = ?, quantity = ?, remarks = ?" + "where id = ? ";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, product.getName());
            pst.setDouble(2, product.getPrice());
            pst.setInt(3, product.getQuantity());
            pst.setString(4, product.getRemarks());
            pst.setLong(5, product.getId());
            int rs = pst.executeUpdate();
            if (rs > 0) {

                return product;

            } else {
                return null;
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProductDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

}
