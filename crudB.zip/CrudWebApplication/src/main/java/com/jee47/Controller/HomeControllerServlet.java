/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jee47.Controller;

import com.jee47.Model.Product;
import com.jee47.Service.InterProductService;
import com.jee47.Service.ProductService;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Adon
 */
public class HomeControllerServlet extends HttpServlet {

    private InterProductService productService;

    @Override
    public void init() throws ServletException {
        productService = new ProductService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String page = "/views/home.jsp";
        HttpSession session = req.getSession();
        if (session.getAttribute("user") == null) {
            session.invalidate();
            resp.sendRedirect("/login?error=true");
        } else {
            List<Product> products = productService.getAll();
            req.setAttribute("products", products);
            req.getRequestDispatcher(page).forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String page = "/views/home.jsp";
        HttpSession session = req.getSession();
        if (session.getAttribute("user") == null) {
            session.invalidate();
            resp.sendRedirect("/login?error=true");
        } else {
            String name = req.getParameter("name");
            String StrPrice = req.getParameter("price");
            String StrQuantity = req.getParameter("quantity");
            String remarks = req.getParameter("remarks");

            double price = StrPrice != null ? Double.parseDouble(StrPrice) : 0;

            int quantity = StrQuantity != null ? Integer.parseInt(StrQuantity) : 0;
            Product product = productService.save(new Product(name, price, quantity, remarks));

            if (product != null) {
                String message = "Save successfull";
                req.setAttribute("success_message", message);

                //for redirect page
                List<Product> products = productService.getAll();
                req.setAttribute("products", products);
 
                
               req.getRequestDispatcher(page).forward(req, resp);
            } else {
                String message = "Save failed";
                req.setAttribute("error_msg", message);
               //req.getRequestDispatcher(page).forward(req, resp);

            }

        }

    }

}
