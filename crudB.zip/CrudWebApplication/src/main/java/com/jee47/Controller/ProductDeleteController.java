/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jee47.Controller;

import com.jee47.Model.Product;
import com.jee47.Service.InterProductService;
import com.jee47.Service.ProductService;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Adon
 */
public class ProductDeleteController extends HttpServlet{
    
   
    

    private InterProductService productService;

    @Override
    public void init() throws ServletException {
        productService = new ProductService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String page = "/views/home.jsp";
        HttpSession session = req.getSession();
        if (session.getAttribute("user") == null) {
            session.invalidate();
            resp.sendRedirect("/login?error=true");
        } else {
            String id  = req.getParameter("id");
            if(id != null){
             boolean isDeleted = productService.delete(Long.parseLong(id));
             if(isDeleted){
                  List<Product> products = productService.getAll();
                req.setAttribute("products", products);
                  req.setAttribute("success_message", " Successfully Deleted ");
               req.getRequestDispatcher(page).forward(req, resp);
             }else{
                 req.setAttribute("error_message", " Deleted failed ");
                 req.getRequestDispatcher(page).forward(req, resp);
             }
             
            }
          
           
        }

    }

   

    

}
