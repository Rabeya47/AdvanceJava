/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jee47.Controller;

import com.jee47.Model.Product;
import com.jee47.Service.InterProductService;
import com.jee47.Service.ProductService;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Adon
 */
public class ProducteditControllerServlet extends HttpServlet {

    private InterProductService productService;

    @Override
    public void init() throws ServletException {
        productService = new ProductService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String page = "/views/home.jsp";
        HttpSession session = req.getSession();
        if (session.getAttribute("user") == null) {
            session.invalidate();
            resp.sendRedirect("/login?error=true");
        } else {
            String id = req.getParameter("id");
            if (id != null) {
                Product product = productService.getProductById(Long.parseLong(id));
                if (product != null) {
                    req.setAttribute("product", product);

                    List<Product> products = productService.getAll();
                    req.setAttribute("products", products);

                    req.getRequestDispatcher(page).forward(req, resp);
                } else {
                    req.setAttribute("error_message", " No Product Found  ");
                    req.getRequestDispatcher(page).forward(req, resp);
                }

            }

        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String page = "/views/home.jsp";
        HttpSession session = req.getSession();
        if (session.getAttribute("user") == null) {
            session.invalidate();
            resp.sendRedirect("/login?error=true");
        } else {
            String id = req.getParameter("id");
            String name = req.getParameter("name");
            String StrPrice = req.getParameter("price");
            String StrQuantity = req.getParameter("quantity");
            String remarks = req.getParameter("remarks");
            long idd =  Long.parseLong(id);
            

            double price = StrPrice != null ? Double.parseDouble(StrPrice) : 0;

            int quantity = StrQuantity != null ? Integer.parseInt(StrQuantity) : 0;
            Product product = productService.update(new Product( idd, name, price, quantity,   remarks));

            if (product != null) {
                String message = "Update successfull";
                req.setAttribute("success_message", message);

                //for redirect page
                List<Product> products = productService.getAll();
                req.setAttribute("products", products);
                
                
                
                
                
               req.getRequestDispatcher(page).forward(req, resp);
            } else {
                String message = "Update failed";
                req.setAttribute("error_msg", message);
               //req.getRequestDispatcher(page).forward(req, resp);

            }

        }


    }
    
    
    
    
    
}
