/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jee47.Controller;

import com.jee47.Model.UserModel;
import com.jee47.Service.InterUserService;
import com.jee47.Service.UserService;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Adon
 */
public class LoginControllerServlet extends HttpServlet {

    private InterUserService userService;

    @Override
    public void init() throws ServletException {
        userService = new UserService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String loginPage = "/Login.jsp";
        req.getRequestDispatcher(loginPage).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String Page = "/Login.jsp";
         HttpSession session = req.getSession();
        
        String username = req.getParameter("username");
        String pwd = req.getParameter("password");

       
        UserModel user = userService.login(username);
        if (user != null && user.getPassword().equals(pwd)) {
            session.setAttribute("user", user);
            user.setPassword(null);
            resp.sendRedirect("http://localhost:8081/home");
            System.out.println("Login success");
        }else{
            req.setAttribute("error", "Login failed please try again");
             System.out.println("Login failed");
            req.getRequestDispatcher(Page).forward(req, resp);
        }

        
    }

}
