# ServletMySQL
JSP, Servlet and MySQL as  backend. 
