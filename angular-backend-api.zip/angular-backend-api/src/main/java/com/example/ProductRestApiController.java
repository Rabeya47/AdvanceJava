/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

import com.example.model.APIResponse;
import com.example.model.Product;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Instructor
 */
@WebServlet(name = "ProductRestApiController", urlPatterns = {"/add_product"})
public class ProductRestApiController extends HttpServlet {

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        //-------start:--get request json data to java object
        Gson gson = new GsonBuilder().setPrettyPrinting().create();  
        StringBuffer jb = Utility.requestBodyToStr(request);
        Product product = gson.fromJson(jb.toString(), Product.class);
        System.out.println("Product: "+ gson.toJson(product));
        //--------end:-get request json data to java object
        
        // code here to send database=========================
        
        //===========response======================
        Map<String, Object> data = new HashMap<String, Object>();
         data.put("product", product);
         
        response.setContentType("application/json");      
        
        
        APIResponse res = new APIResponse("Save Successful", data, 200);
        PrintWriter out = response.getWriter();
        
        out.write(gson.toJson(res));
        out.flush();
        out.close();
        
    }

}
