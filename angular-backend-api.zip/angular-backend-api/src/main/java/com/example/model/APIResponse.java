/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.model;

import java.util.Map;

/**
 *
 * @author Instructor
 */
public class APIResponse {
    
    String message;
    Map<String, Object> data;
    int statusCode;

    public APIResponse(String message, Map<String, Object> data, int statusCode) {
        this.message = message;
        this.data = data;
        this.statusCode = statusCode;
    }
    
    
    
}
